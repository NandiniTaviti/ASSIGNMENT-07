const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser'); // Import cookie-parser
const jwt = require('jsonwebtoken'); // Import jsonwebtoken
const User = require('./models/User');
const auth = require('./middleware/auth'); // Import auth middleware

// Load environment variables from .env file
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to serve static files (CSS, JS, Images)
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cookieParser()); // Use cookie-parser middleware

// MongoDB connection
const mongoDB = process.env.MONGO_URL;
mongoose.connect(mongoDB)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

// Route to serve main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route for user registration
app.post('/register', async (req, res) => {
    const { firstname, middlename, lastname, username, email, phone, password } = req.body;

    // Validate required fields
    if (!firstname || !lastname || !username || !email || !password) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, parseInt(process.env.BCRYPT_SALT_ROUNDS));
        const newUser = new User({ firstname, middlename, lastname, username, email, phone, password: hashedPassword });
        await newUser.save();
        console.log('Registered User:', newUser); // Debugging line
        res.json({ message: 'Registration successful' });
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Route for user login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username });
        console.log('Found User:', user); // Log found user

        if (user) {
            const isMatch = await bcrypt.compare(password, user.password);
            console.log('Stored Password Hash:', user.password); // Log stored password hash
            console.log('Provided Password:', password); // Log provided password
            console.log('Password Match:', isMatch); // Log password comparison result

            if (isMatch) {
                // Generate a JWT token
                const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

                // Set token in cookies
                res.cookie('token', token, {
                    httpOnly: true,
                    secure: process.env.NODE_ENV === 'production', // Use secure cookies in production
                    maxAge: 3600000 // 1 hour
                });

                return res.json({ message: 'Login successful' });
            } else {
                return res.status(401).json({ message: 'Wrong credentials, login again' });
            }
        } else {
            return res.status(401).json({ message: 'Wrong credentials, login again' });
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).send('Server error');
    }
});

// Protected route example
app.get('/protected', auth.protect, (req, res) => {
    res.json({ message: 'This is a protected route', user: req.user });
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { error: err });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});



// const express = require('express');
// const path = require('path');
// const mongoose = require('mongoose');
// const bcrypt = require('bcrypt');
// const dotenv = require('dotenv');
// const cookieParser = require('cookie-parser');
// const jwt = require('jsonwebtoken'); // Import jwt
// const User = require('./models/User');
// const auth = require('./middleware/auth');

// // Load environment variables from .env file
// dotenv.config();

// const app = express();
// const PORT = process.env.PORT || 3000;

// // Set EJS as the templating engine
// app.set('view engine', 'ejs');
// app.set('views', path.join(__dirname, 'views')); // Set the views directory

// // Middleware to serve static files (CSS, JS, Images)
// app.use(express.static(path.join(__dirname, 'public')));
// app.use(express.urlencoded({ extended: false }));
// app.use(express.json());
// app.use(cookieParser()); // Use cookie-parser middleware

// // MongoDB connection
// const mongoDB = process.env.MONGO_URL;
// mongoose.connect(mongoDB)
//     .then(() => console.log('MongoDB connected'))
//     .catch(err => console.error('MongoDB connection error:', err));

// // Route to serve main HTML file
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Route for user registration
// app.post('/register', async (req, res) => {
//     const { firstname, middlename, lastname, username, email, phone, password } = req.body;

//     // Validate required fields
//     if (!firstname || !lastname || !username || !email || !password) {
//         return res.status(400).json({ message: 'Missing required fields' });
//     }

//     try {
//         const existingUser = await User.findOne({ username });
//         if (existingUser) {
//             return res.status(400).json({ message: 'User already exists' });
//         }

//         const hashedPassword = await bcrypt.hash(password, parseInt(process.env.BCRYPT_SALT_ROUNDS));
//         const newUser = new User({ firstname, middlename, lastname, username, email, phone, password: hashedPassword });
//         await newUser.save();
//         res.json({ message: 'Registration successful' });
//     } catch (error) {
//         console.error('Error during registration:', error);
//         res.status(500).json({ message: 'Server error' });
//     }
// });

// // Route for user login
// app.post('/login', async (req, res) => {
//     const { username, password } = req.body;

//     try {
//         const user = await User.findOne({ username });
//         if (user && await bcrypt.compare(password, user.password)) {
//             // Generate a JWT token
//             const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

//             // Set token in cookies
//             res.cookie('token', token, {
//                 httpOnly: true,
//                 secure: process.env.NODE_ENV === 'production',
//                 maxAge: 3600000 // 1 hour
//             });

//             return res.json({ message: 'Login successful' });
//         } else {
//             return res.status(401).json({ message: 'Wrong credentials, login again' });
//         }
//     } catch (error) {
//         console.error('Error during login:', error);
//         res.status(500).send('Server error');
//     }
// });

// // Protected route example (rendering dynamic content with EJS)
// app.get('/dashboard', auth.protect, async (req, res) => {
//     // Fetch user-specific data from MongoDB
//     try {
//         const user = await User.findById(req.user._id);
//         res.render('dashboard', { user });
//     } catch (error) {
//         console.error('Error fetching user data:', error);
//         res.status(500).send('Server error');
//     }
// });

// // Logout route
// app.post('/logout', (req, res) => {
//     res.clearCookie('token');
//     res.redirect('/'); // Redirect to homepage after logout
// });

// // Error handling
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).render('error', { error: err });
// });

// // Start the server
// app.listen(PORT, () => {
//     console.log(`Server is running on  http://localhost:${PORT}`);
// });
