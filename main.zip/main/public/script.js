document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('#login form');
    const loginUsernameInput = loginForm.querySelector('input[type="text"]');
    const loginPasswordInput = loginForm.querySelector('input[type="password"]');
    
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        loginUsernameInput.classList.remove('error');
        loginPasswordInput.classList.remove('error');
        
        const username = loginUsernameInput.value.trim();
        const password = loginPasswordInput.value.trim();
        let hasError = false;
        
        const usernameRegex = /^[a-zA-Z]+$/;
        if (!usernameRegex.test(username)) {
            loginUsernameInput.classList.add('error');
            alert('Username must contain letters only.');
            hasError = true;
        }
        
        if (!password) {
            loginPasswordInput.classList.add('error');
            alert('Please enter your password.');
            hasError = true;
        }
        
        if (!hasError) {
            // Send a POST request to the server
            try {
                const response = await fetch('/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, password })
                });

                const responseText = await response.text();
                document.body.innerHTML = responseText; // Update the page with the server response
            } catch (error) {
                console.error('Error during login:', error);
                alert('An error occurred while logging in.');
            }
        }
    });
    
    const registerForm = document.querySelector('#register form');
    const regUsernameInput = registerForm.querySelector('input[placeholder="Username"]');
    const regPasswordInput = registerForm.querySelector('input[type="password"]');
    const confirmPasswordInput = registerForm.querySelector('input[placeholder="Confirm password"]');
    
    registerForm.addEventListener('submit', function(event) {
        if (regPasswordInput.value !== confirmPasswordInput.value) {
            event.preventDefault();
            alert('Passwords do not match. Please try again.');
            confirmPasswordInput.focus();
            return;
        }
        
        regUsernameInput.classList.remove('error');
        
        const usernameRegex = /^[a-zA-Z]+$/;
        if (!usernameRegex.test(regUsernameInput.value.trim())) {
            regUsernameInput.classList.add('error');
            alert('Username must contain letters only.');
            event.preventDefault();
            return;
        }
        
        alert('Registration successful!');
    });
});
