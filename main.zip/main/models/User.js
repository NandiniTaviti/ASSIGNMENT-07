const mongoose = require('mongoose');

// Define the User schema
const userSchema = new mongoose.Schema({
    firstname: { type: String, required: true },
    middlename: { type: String, required: false },
    lastname: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    password: { type: String, required: true }
}, {
    timestamps: true // Automatically manage createdAt and updatedAt fields
});

// Create a User model from the schema
const User = mongoose.model('User', userSchema);

module.exports = User; // Export the User model
